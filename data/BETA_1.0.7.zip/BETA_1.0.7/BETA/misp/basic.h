#include "kseq.h"

int bg_counter(long* acnt, long* ccnt, char* seq);



