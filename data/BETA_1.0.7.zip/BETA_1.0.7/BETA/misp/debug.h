#ifndef MIS_DEBUG_H
#define MIS_DEBUG_H


/* #define DBG(exp) 2 */
#endif
